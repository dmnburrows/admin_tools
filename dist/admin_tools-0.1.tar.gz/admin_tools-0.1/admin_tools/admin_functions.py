
#================================    
class ad_tools: 
#================================    
    """
    Class to simulate spatial transciptomic spot data, where each spot contains a mixture of cells of different gene expression patterns.
    
    """
    
    #========================
    def __init__(self):
    #========================
        self.n_clusts = 5



    def prac(self,x,y):
        """
            This function is a practice. 


        Inputs:

        Outputs:

            """

        z=x+y
        return(z,y)
    
    
    
